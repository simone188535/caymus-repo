<?php get_header(); ?>
<div class="wrap" id="top-breadcrumb-wrap">
			<div class="container">
			<ul class="breadcrumb" id="top-breadcrumb">
			  <li><a href="<?php bloginfo('url'); ?>">Home</a> <span class="divider">/</span></li>
			  <li class="active"><a href="#">Error 404</a></li>
			</ul>
			</div>
			</div>	
			<div class="container" id="main-content">

	<h2>Error 404 - Page Not Found</h2>
	</div>
<!--?php get_sidebar(); ?-->

<?php get_footer(); ?>