		<!--/div-->
		<div id="company-info" class="wrap">
	<div class="container" id="co-info-content">
		<div class="span4">
			<strong>CAYMUS EQUITY PARTNERS LLC</strong><br />
	<p>Securities Offered through Caymus Securities LLC,
	Member FINRA/SIPC</p>
	</div>
	<div id="foot-divider"><img src="img/no-image.gif" /></div>
	<div class="span2">
		<strong>CONTACT INFO</strong>
	</div>
	<div class="span2"><strong>ATLANTA</strong><br />
	<p>One Securities Centre<br />
	3490 Piedmont Rd NE<br />
	Suite 1040<br />
	Atlanta, GA 30305<br />
	T (404) 995-8300<br />
	</p>
	</div>
	<div class="span2">
		<strong>NEW YORK</strong><br />
	<p>641 Lexington Avenue<br />
	17th Floor<br />
	New York, NY 10022<br />
	T (212) 755-3600<br />
	</p>
	</div>
	<div class="span2">
		<strong>PHOENIX</strong><br />
	<p>19820 N. 7th Street<br />
	Suite 290<br />
	Phoenix, AZ 85024<br />
	T (623) 680-0406<br />
	</p>
	</div>
	</div>
</div>
<div id="footer-info" class="wrap">
	<p><a href="<?php bloginfo('url'); ?>">Home</a>   |   <a href="/privacy-policy">Privacy Policy</a>   |   <a href="/terms-and-conditions">Terms &amp; Conditions</a>   |   © Copyright 2013 Caymus Equity Partners LLC</p>
</div>
<script src="<?php bloginfo('template_directory'); ?>/js/jquery.js" type="text/javascript"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/bootstrap.js" type="text/javascript"></script>
<!--[if IE]>
<script src="<?php bloginfo('template_directory'); ?>/js/bootstrap-carousel.js" type="text/javascript"></script>
<![endif]--> 
<script src="<?php bloginfo('template_directory'); ?>/js/main-sc.js" type="text/javascript"></script>
		
		<!--<div id="footer">
			&copy;<?php echo date("Y"); echo " "; bloginfo('name'); ?>
		</div>
	</div>-->
	<!--</div>-->

	<?php wp_footer(); ?>
	
	<!-- Don't forget analytics -->
	
</body>

</html>